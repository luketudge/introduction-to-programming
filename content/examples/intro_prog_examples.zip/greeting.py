# -*- coding: utf-8 -*-
"""
A program to print out a welcome message.
"""

# TODO: Personalize the greeting by getting the user's name.

# This is the command that prints out the message:
print('Hello.')
