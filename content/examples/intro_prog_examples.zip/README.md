# Example programs

This directory contains the example Python programs discussed in the topic notes.

Some examples make use of additional data files. These are provided in the [data](data) subdirectory. The examples assume that this directory structure is preserved if you download and unzip the archive, i.e. they will look for the data files in a subdirectory called *data*.
