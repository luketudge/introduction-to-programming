print('Hello.')
