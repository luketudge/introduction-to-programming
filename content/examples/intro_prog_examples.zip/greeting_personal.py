# -*- coding: utf-8 -*-
"""
A program to print out a personal welcome message.
Gets the user to type in their name.
"""

# Get the user to type in their name in the console.
# Store the result in a variable.
name = input('What is your name?')

# Combine the name with a welcome message.
# Store the result in a new variable.
message = 'Hello ' + name

# Print out the contents of the welcome message variable.
print(message)
